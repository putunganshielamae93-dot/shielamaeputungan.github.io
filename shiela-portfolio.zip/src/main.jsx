import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  ArrowUpRight, BriefcaseBusiness, Check, ChevronRight, Download,
  FileSpreadsheet, Github, Linkedin, Mail, MapPin, Menu, Moon,
  Ruler, Search, Sparkles, Sun, X
} from "lucide-react";
import "./index.css";

const LINKS = {
  github: "YOUR_GITHUB_URL",
  linkedin: "https://linkedin.com/in/shiela-mae-putungan-877042318/",
  onlinejobs: "YOUR_ONLINEJOBS_URL",
  email: "putunganshielamae93@gmail.com"
};

const projects = [
  {
    title: "Excel Data Analysis Dashboard",
    category: "Data & Administration",
    description: "A sample Excel project demonstrating organized data, formulas, PivotTables, VLOOKUP, and clear presentation of useful information.",
    tools: ["Microsoft Excel", "PivotTables", "VLOOKUP"],
    icon: FileSpreadsheet
  },
  {
    title: "Construction Data & Estimating Workbook",
    category: "Construction Support",
    description: "A sample workbook focused on organized quantities, materials, calculations, and BOQ/BOM-style data.",
    tools: ["Excel", "BOQ/BOM", "Data Organization"],
    icon: Ruler
  },
  {
    title: "AutoCAD Technical Drawing",
    category: "CAD & Engineering",
    description: "A sample CAD project demonstrating drafting, dimensions, layouts, and technical drawing organization.",
    tools: ["AutoCAD", "Technical Drawings"],
    icon: Ruler
  },
  {
    title: "SketchUp 3D Model",
    category: "CAD & Engineering",
    description: "A sample 3D model demonstrating basic architectural and construction visualization.",
    tools: ["SketchUp", "3D Modeling"],
    icon: Sparkles
  },
  {
    title: "PowerPoint Presentation Design",
    category: "Digital & Creative",
    description: "A presentation project focused on clean layouts, information organization, visual hierarchy, and readability.",
    tools: ["PowerPoint", "Canva"],
    icon: Sparkles
  },
  {
    title: "Social Media & Digital Content",
    category: "Digital & Creative",
    description: "A collection of sample social media graphics, digital products, and content designs.",
    tools: ["Canva", "CapCut"],
    icon: Sparkles
  }
];

const skillGroups = [
  {
    title: "Data & Administration",
    items: ["Microsoft Excel", "Data Entry", "Data Cleaning", "Data Analysis", "Pivot Tables", "VLOOKUP", "Microsoft Office", "Google Workspace", "Document Organization"]
  },
  {
    title: "Construction & Engineering",
    items: ["AutoCAD", "SketchUp", "BOQ / BOM Estimating", "Construction Documentation", "Quantity Takeoff Basics", "Technical Drawings"]
  },
  {
    title: "Digital & Creative",
    items: ["Canva", "PowerPoint", "CapCut", "Social Media Posting", "Digital Products", "Basic Content Creation"]
  },
  {
    title: "Remote Work",
    items: ["Administrative Support", "Research", "Email Communication", "File Organization", "Attention to Detail", "Time Management", "Fast Learning"]
  }
];

function App() {
  const [dark, setDark] = useState(false);
  const [menu, setMenu] = useState(false);

  useEffect(() => {
    document.documentElement.dataset.theme = dark ? "dark" : "light";
  }, [dark]);

  const close = () => setMenu(false);

  return (
    <div className="app">
      <header className="nav">
        <a className="brand" href="#home" onClick={close}>
          <span className="brand-mark">S</span>
          <span>Shiela<span className="dot">.</span></span>
        </a>
        <nav className={menu ? "nav-links open" : "nav-links"}>
          {["About", "Skills", "Projects", "Experience", "Certifications", "Contact"].map(item => (
            <a key={item} href={`#${item.toLowerCase()}`} onClick={close}>{item}</a>
          ))}
        </nav>
        <div className="nav-actions">
          <button className="icon-btn" aria-label="Toggle theme" onClick={() => setDark(v => !v)}>
            {dark ? <Sun size={18}/> : <Moon size={18}/>}
          </button>
          <button className="menu-btn" aria-label="Toggle menu" onClick={() => setMenu(v => !v)}>
            {menu ? <X/> : <Menu/>}
          </button>
        </div>
      </header>

      <main>
        <section id="home" className="hero section">
          <div className="hero-copy">
            <div className="eyebrow"><span className="pulse"></span> Open to remote opportunities</div>
            <h1>Hi, I'm <span>Shiela.</span><br/>I make work more <em>organized.</em></h1>
            <p className="hero-text">
              Detail-oriented and adaptable professional with a civil engineering background,
              experience in academic and project-related work, and growing skills in data,
              administrative support, CAD, and digital tools.
            </p>
            <div className="hero-buttons">
              <a className="btn primary" href="#projects">View My Work <ArrowUpRight size={17}/></a>
              <a className="btn secondary" href="/resume.pdf" download>Download Resume <Download size={17}/></a>
            </div>
            <div className="socials">
              <a href={LINKS.github} target="_blank" rel="noreferrer" aria-label="GitHub"><Github size={19}/></a>
              <a href={LINKS.linkedin} target="_blank" rel="noreferrer" aria-label="LinkedIn"><Linkedin size={19}/></a>
              <a href={`mailto:${LINKS.email}`} aria-label="Email"><Mail size={19}/></a>
              <span className="location"><MapPin size={16}/> Laguna, Philippines</span>
            </div>
          </div>
          <div className="hero-card">
            <div className="card-glow"></div>
            <div className="profile-placeholder">
              <span>SM</span>
            </div>
            <div className="hero-card-content">
              <p className="small-label">CURRENT FOCUS</p>
              <h3>Remote Support + Technical Work</h3>
              <div className="mini-tags">
                <span>Excel</span><span>Data</span><span>CAD</span><span>VA</span>
              </div>
            </div>
          </div>
        </section>

        <section id="about" className="section split">
          <div>
            <p className="section-kicker">01 — About me</p>
            <h2>A technical background with a practical, organized mindset.</h2>
          </div>
          <div className="about-copy">
            <p>
              I'm a Civil Engineering student/soon-to-be graduate building my career in remote work.
              My background has given me experience with technical documentation, Excel-based work,
              engineering software, and tasks that require accuracy and organization.
            </p>
            <p>
              I'm interested in virtual assistance, data entry and analysis, construction support,
              CAD drafting, research, and administrative work. I'm continuously learning new tools
              and workflows while keeping my approach simple: understand the task, stay organized,
              check the details, and communicate clearly.
            </p>
            <div className="about-facts">
              <div><strong>2026</strong><span>DPWH OJT Intern</span></div>
              <div><strong>Excel</strong><span>Data & organization</span></div>
              <div><strong>CAD</strong><span>AutoCAD + SketchUp</span></div>
            </div>
          </div>
        </section>

        <section id="skills" className="section">
          <div className="section-heading">
            <div>
              <p className="section-kicker">02 — Skills</p>
              <h2>Tools I can work with.</h2>
            </div>
            <p>My skills are a mix of technical, administrative, data, and creative capabilities.</p>
          </div>
          <div className="skill-grid">
            {skillGroups.map((group, i) => (
              <article className="skill-card" key={group.title}>
                <span className="skill-number">0{i + 1}</span>
                <h3>{group.title}</h3>
                <div className="skill-list">{group.items.map(s => <span key={s}><Check size={14}/>{s}</span>)}</div>
              </article>
            ))}
          </div>
        </section>

        <section id="projects" className="section tinted">
          <div className="section-heading">
            <div>
              <p className="section-kicker">03 — Selected work</p>
              <h2>Projects & portfolio.</h2>
            </div>
            <p>Sample and academic work are clearly identified so employers can see what I can do without overstating professional experience.</p>
          </div>
          <div className="project-grid">
            {projects.map((p, i) => {
              const Icon = p.icon;
              return <article className="project-card" key={p.title}>
                <div className="project-visual"><Icon size={32}/><span>PROJECT 0{i + 1}</span></div>
                <div className="project-body">
                  <span className="project-category">{p.category}</span>
                  <h3>{p.title}</h3>
                  <p>{p.description}</p>
                  <div className="tool-row">{p.tools.map(t => <span key={t}>{t}</span>)}</div>
                  <div className="project-links">
                    <a href="#contact">View Details <ChevronRight size={15}/></a>
                    <a href={LINKS.github} target="_blank" rel="noreferrer">GitHub <Github size={15}/></a>
                  </div>
                </div>
              </article>
            })}
          </div>
        </section>

        <section id="experience" className="section">
          <div className="section-heading">
            <div><p className="section-kicker">04 — Experience</p><h2>Where I've learned by doing.</h2></div>
          </div>
          <div className="timeline">
            <Timeline year="2026" title="Department of Public Works and Highways — OJT Intern">
              <p>Gained professional exposure in a government infrastructure and public-works environment.</p>
              <p>Strengthened practical understanding of technical and project-related work, workplace standards, coordination, and accuracy.</p>
            </Timeline>
            <Timeline year="2020" title="Creotec Technical Group — Work Immersion">
              <p>Completed workplace-based learning as part of academic preparation.</p>
              <p>Developed adaptability, responsibility, time management, attention to detail, and familiarity with professional work practices.</p>
            </Timeline>
            <Timeline year="Academic" title="Civil Engineering & Project Work">
              <p>Worked on academic and project-related tasks involving Excel, data, technical documentation, AutoCAD, SketchUp, and construction-related requirements.</p>
            </Timeline>
          </div>
        </section>

        <section id="certifications" className="section tinted">
          <div className="section-heading">
            <div><p className="section-kicker">05 — Training</p><h2>Certifications & development.</h2></div>
          </div>
          <div className="cert-grid">
            {[
              ["2024", "Safety Officer 2", "40 Hours Construction Occupational Safety and Health + 2 Hours Training of Trainers"],
              ["2024", "Advanced MS Excel", "Training"],
              ["2024", "Building Your Wealth", "Training / Seminar"],
              ["2024", "Professional Branding 101", "Training / Seminar"],
              ["2024", "Maximizing Your Potential", "Training / Seminar"],
              ["2023", "Binance Academy Academic Tour", "Academic Tour"],
              ["2023", "Casio Calculator Technique", "Training / Seminar"],
              ["In Progress", "TEFL Certificate", "To be added when completed"]
            ].map(([year, title, desc]) => (
              <article className="cert-card" key={title}>
                <span>{year}</span><div><h3>{title}</h3><p>{desc}</p></div>
              </article>
            ))}
          </div>
        </section>

        <section id="github" className="section github-section">
          <div className="github-box">
            <Github size={42}/>
            <div>
              <p className="section-kicker">06 — GitHub</p>
              <h2>Build in public, one project at a time.</h2>
              <p>This portfolio can grow with my GitHub profile as I add Excel, data, CAD, automation, and other practical projects.</p>
            </div>
            <a className="btn primary" href={LINKS.github} target="_blank" rel="noreferrer">Visit My GitHub <ArrowUpRight size={17}/></a>
          </div>
        </section>

        <section id="resume" className="section resume-section">
          <div className="resume-card">
            <div><p className="section-kicker">07 — Resume</p><h2>Want the details?</h2><p>Download my current resume for my education, experience, skills, and professional development.</p></div>
            <a className="btn primary" href="/resume.pdf" download>Download Resume <Download size={17}/></a>
          </div>
        </section>

        <section id="contact" className="section contact-section">
          <div>
            <p className="section-kicker">08 — Contact</p>
            <h2>Let's connect.</h2>
            <p>I'm open to remote opportunities, freelance projects, and entry-level roles where I can contribute, learn, and grow.</p>
            <div className="contact-links">
              <a href={`mailto:${LINKS.email}`}><Mail size={18}/>{LINKS.email}</a>
              <a href={LINKS.linkedin} target="_blank" rel="noreferrer"><Linkedin size={18}/>LinkedIn</a>
              <a href={LINKS.github} target="_blank" rel="noreferrer"><Github size={18}/>GitHub</a>
            </div>
          </div>
          <form className="contact-form" onSubmit={e => { e.preventDefault(); alert("This form is currently a demo. Connect it to Formspree or EmailJS to receive messages."); }}>
            <label>Name<input required name="name" placeholder="Your name"/></label>
            <label>Email<input required type="email" name="email" placeholder="you@example.com"/></label>
            <label>Message<textarea required name="message" rows="5" placeholder="How can I help?"></textarea></label>
            <button className="btn primary" type="submit">Send Message <ArrowUpRight size={17}/></button>
          </form>
        </section>
      </main>

      <footer className="footer">
        <div><span className="brand-mark small">S</span> © 2026 Shiela Mae Putungan. All rights reserved.</div>
        <div><a href={LINKS.github}>GitHub</a><a href={LINKS.linkedin}>LinkedIn</a><a href={`mailto:${LINKS.email}`}>Email</a></div>
      </footer>
    </div>
  );
}

function Timeline({year, title, children}) {
  return <article className="timeline-item">
    <div className="timeline-dot"></div>
    <div className="timeline-meta">{year}</div>
    <div className="timeline-content"><h3>{title}</h3>{children}</div>
  </article>
}

createRoot(document.getElementById("root")).render(<App />);